#include "Tone.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>

#ifdef __cplusplus
}
#endif

void noTone(uint8_t pin) {
	return;
}

void tone(uint8_t pin, unsigned int frequency, unsigned long duration) {
	return;
}
