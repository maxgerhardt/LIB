#include "constants.h"		// Just for some macros, such as INPUT
#include "wiring_interrupt.h"


void interrupts(void) {

}

void noInterrupts(void) {

}
